# uncompyle6 version 3.7.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.17 (default, Sep 30 2020, 13:38:04) 
# [GCC 7.5.0]
# Embedded file name: /usr/lib/enigma2/python/Components/Renderer/VolumeText.py
# Compiled at: 2013-02-23 18:07:32
from Components.VariableText import VariableText
from enigma import eLabel, eDVBVolumecontrol, eTimer
from Renderer import Renderer

class TNVolumeText(Renderer, VariableText):

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.vol_timer = eTimer()
        self.vol_timer.callback.append(self.pollme)

    GUI_WIDGET = eLabel

    def changed(self, what):
        if not self.suspended:
            self.text = str(eDVBVolumecontrol.getInstance().getVolume())

    def pollme(self):
        self.changed(None)
        return

    def onShow(self):
        self.suspended = False
        self.vol_timer.start(200)

    def onHide(self):
        self.suspended = True
        self.vol_timer.stop()